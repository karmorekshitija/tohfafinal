import { useState, useEffect, useRef, useCallback } from "react";
import botanicalHero from "@/imports/image.png";

const PINE = "#14381F";
const IVORY = "#FAF6EE";
const TERRACOTTA = "#C85A32";

// ─── Mock Data ────────────────────────────────────────────────────────────────

const MOCK_SLIDES = [
  { id: 1, image_url: "https://images.unsplash.com/photo-1595351298020-038700609878?w=1200&q=75", alt_text: "Handcrafted Pottery" },
  { id: 2, image_url: "https://images.unsplash.com/photo-1590605095243-072811dbe64c?w=1200&q=75", alt_text: "Artisan Ceramics" },
  { id: 3, image_url: "https://images.unsplash.com/photo-1609881583302-61548332039c?w=1200&q=75", alt_text: "Handmade Craft" },
];

const MOCK_PRODUCTS = [
  { id: 1, name: "Handcrafted Ceramic Bowl", seller_name: "Earth & Clay Studio", price_paise: 185000, image_url: "https://images.unsplash.com/photo-1595351298020-038700609878?w=400&q=70", avg_rating: 4.8, review_count: 23, is_bestseller: true, listing_type: "standard" },
  { id: 2, name: "Hand-Woven Linen Journal", seller_name: "The Paper Loom", price_paise: 95000, image_url: "https://images.unsplash.com/photo-1609881583302-61548332039c?w=400&q=70", avg_rating: 4.6, review_count: 12, is_bestseller: false, listing_type: "custom" },
  { id: 3, name: "Terracotta Incense Holder", seller_name: "Aura Metals", price_paise: 120000, image_url: "https://images.unsplash.com/photo-1590605095243-072811dbe64c?w=400&q=70", avg_rating: 4.9, review_count: 45, is_bestseller: true, listing_type: "standard" },
  { id: 4, name: "Minimalist Stoneware Vase", seller_name: "Nordic Craft Co.", price_paise: 240000, image_url: "https://images.unsplash.com/photo-1612945578381-6481cdd73b0a?w=400&q=70", avg_rating: 0, review_count: 0, is_bestseller: false, listing_type: "standard" },
  { id: 5, name: "Block Print Silk Scarf", seller_name: "Jaipuri Threads", price_paise: 149000, image_url: "https://images.unsplash.com/photo-1629649213060-4874f8f6bce3?w=400&q=70", avg_rating: 4.5, review_count: 8, is_bestseller: false, listing_type: "custom" },
  { id: 6, name: "Hand-turned Wooden Bowl", seller_name: "Forest & Form", price_paise: 320000, image_url: "https://images.unsplash.com/photo-1595351298020-038700609878?w=400&q=70", avg_rating: 4.9, review_count: 18, is_bestseller: true, listing_type: "standard" },
  { id: 7, name: "Macramé Wall Hanging", seller_name: "Knot & Grain", price_paise: 175000, image_url: "https://images.unsplash.com/photo-1590605095243-072811dbe64c?w=400&q=70", avg_rating: 0, review_count: 0, is_bestseller: false, listing_type: "standard" },
  { id: 8, name: "Raku Fired Tea Set", seller_name: "Earth & Clay Studio", price_paise: 480000, image_url: "https://images.unsplash.com/photo-1609881583302-61548332039c?w=400&q=70", avg_rating: 4.7, review_count: 31, is_bestseller: false, listing_type: "standard" },
];

const SPONSORED_PRODUCTS = [
  { id: 101, name: "Handcrafted Ceramic Bowls (Set of 2)", seller_name: "Earth & Clay Studio", price_paise: 185000, image_url: "https://images.unsplash.com/photo-1595351298020-038700609878?w=400&q=70", avg_rating: 4.8, review_count: 23, listing_type: "standard" },
  { id: 102, name: "Handmade Linen Journal", seller_name: "The Paper Loom", price_paise: 95000, image_url: "https://images.unsplash.com/photo-1609881583302-61548332039c?w=400&q=70", avg_rating: 4.6, review_count: 12, listing_type: "custom" },
  { id: 103, name: "Solid Brass Incense Holder", seller_name: "Aura Metals", price_paise: 120000, image_url: "https://images.unsplash.com/photo-1590605095243-072811dbe64c?w=400&q=70", avg_rating: 4.9, review_count: 45, listing_type: "standard" },
  { id: 104, name: "Minimalist Stoneware Vase", seller_name: "Nordic Craft Co.", price_paise: 240000, image_url: "https://images.unsplash.com/photo-1612945578381-6481cdd73b0a?w=400&q=70", avg_rating: 0, review_count: 0, listing_type: "standard" },
];

const OCCASIONS = [
  { name: "Anniversary", image: "https://images.unsplash.com/photo-1553578622-34d24027ce18?w=400&q=70", slug: "anniversary" },
  { name: "Birthday", image: "https://images.unsplash.com/photo-1545696563-af8f6ec2295a?w=400&q=70", slug: "birthday" },
  { name: "Rakhi", image: "https://images.unsplash.com/photo-1629649213060-4874f8f6bce3?w=400&q=70", slug: "rakhi" },
  { name: "Wedding", image: "https://images.unsplash.com/photo-1740674570259-a47d713a2976?w=400&q=70", slug: "wedding" },
  { name: "Friendship", image: "https://images.unsplash.com/photo-1784292765863-20dddb419e67?w=400&q=70", slug: "friendship" },
  { name: "Mother's Day", image: "https://images.unsplash.com/photo-1553578622-34d24027ce18?w=400&q=70", slug: "mothers-day" },
  { name: "Father's Day", image: "https://images.unsplash.com/photo-1609881583302-61548332039c?w=400&q=70", slug: "fathers-day" },
];

const TRUST_ITEMS = [
  { icon: "✦", title: "Made With Meaning", desc: "Every piece crafted with intention" },
  { icon: "◈", title: "Customised For You", desc: "Personalised to tell your story" },
  { icon: "⊕", title: "Trusted Creators", desc: "Vetted artisans across India" },
  { icon: "◎", title: "Pan-India Delivery", desc: "Delivered with care, anywhere" },
];

const MOCK_CATEGORIES = [
  { display_name: "Ceramics & Pottery", slug: "ceramics" },
  { display_name: "Textiles & Weaves", slug: "textiles" },
  { display_name: "Stationery & Paper", slug: "stationery" },
];

// ─── Navbar ───────────────────────────────────────────────────────────────────

function Navbar() {
  return (
    <header
      className="w-full sticky top-0 z-50 border-b flex justify-between items-center px-4 md:px-8 lg:px-12 h-16 md:h-20"
      style={{ backgroundColor: IVORY, borderColor: "rgba(20,56,31,0.2)" }}
    >
      {/* Logo */}
      <div className="flex items-center flex-1">
        <a
          href="#"
          className="select-none"
          style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: "clamp(24px,4vw,32px)",
            fontStyle: "italic",
            color: PINE,
            textDecoration: "none",
          }}
        >
          Tohfa<span style={{ color: PINE }}>.</span>
        </a>
      </div>

      {/* Desktop Nav */}
      <nav className="hidden md:flex items-center justify-center gap-6 lg:gap-8 h-full">
        {[
          { label: "Home", active: true },
          { label: "Category", active: false },
          { label: "ZipGift", active: false },
          { label: "Profile", active: false },
        ].map(({ label, active }) => (
          <a
            key={label}
            href="#"
            className="flex items-center gap-1.5 h-full px-1 transition-colors"
            style={{
              fontFamily: "'DM Sans', sans-serif",
              fontSize: "15px",
              color: active ? PINE : "#414942",
              borderBottom: active ? `2px solid ${PINE}` : "2px solid transparent",
              textDecoration: "none",
            }}
          >
            {label}
          </a>
        ))}
      </nav>

      {/* Right Icons */}
      <div className="flex items-center justify-end flex-1 gap-1 sm:gap-2">
        {["search", "favorite", "shopping_cart", "notifications"].map((icon) => (
          <button
            key={icon}
            className="p-2 rounded-full transition-all active:scale-95 relative"
            style={{ color: PINE, background: "transparent" }}
            onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "rgba(20,56,31,0.08)")}
            onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
          >
            <span
              className="material-symbols-outlined"
              style={{ fontSize: "22px", fontVariationSettings: icon === "favorite" ? "'FILL' 1" : "'FILL' 0" }}
            >
              {icon}
            </span>
          </button>
        ))}
        <div className="flex items-center gap-2 ml-2 md:ml-4">
          <a
            href="#"
            className="hidden sm:block text-sm font-semibold hover:underline"
            style={{ color: PINE, fontFamily: "'DM Sans', sans-serif" }}
          >
            Login
          </a>
          <a
            href="#"
            className="text-white text-sm font-semibold px-3 py-1.5 rounded-lg transition-opacity hover:opacity-90"
            style={{ backgroundColor: PINE, fontFamily: "'DM Sans', sans-serif" }}
          >
            Register
          </a>
        </div>
      </div>
    </header>
  );
}

// ─── Botanical Banner ─────────────────────────────────────────────────────────

function BotanicalBanner() {
  return (
    <section
      className="relative w-full overflow-hidden"
      style={{ height: "clamp(280px, 40vw, 520px)" }}
    >
      {/* Background image */}
      <img
        src={botanicalHero}
        alt="Botanical hanging greenery arrangement"
        className="absolute inset-0 w-full h-full object-cover"
        style={{ objectPosition: "center top" }}
        loading="eager"
      />

      {/* Dark overlay for depth */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(to bottom, rgba(13,38,20,0.15) 0%, rgba(13,38,20,0.05) 50%, rgba(13,38,20,0.1) 60%, rgba(20,56,31,0.4) 75%, rgba(20,56,31,0.72) 85%, #0D2614 95%, #0D2614 100%)",
        }}
      />

      {/* Fade bottom to ivory */}
      <div
        className="absolute bottom-0 left-0 right-0"
        style={{
          height: "35%",
          background: `linear-gradient(to bottom, transparent 0%, #0D2614 40%, ${IVORY} 100%)`,
        }}
      />

      {/* "Tohfa" wordmark — vertically centered in upper 70% */}
      <div
        className="absolute inset-0 flex items-center justify-center"
        style={{ paddingBottom: "15%" }}
      >
        <h1
          className="text-center tracking-wide"
          style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: "clamp(64px, 12vw, 160px)",
            fontStyle: "italic",
            fontWeight: 400,
            color: IVORY,
            lineHeight: 1,
            letterSpacing: "-0.01em",
            textShadow: "0 4px 32px rgba(0,0,0,0.3)",
          }}
        >
          Tohfa
        </h1>
      </div>
    </section>
  );
}

// ─── Hero Slideshow ───────────────────────────────────────────────────────────

function HeroSlideshow() {
  const [current, setCurrent] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const slides = MOCK_SLIDES;

  const goTo = useCallback(
    (idx: number) => {
      const next = ((idx % slides.length) + slides.length) % slides.length;
      setCurrent(next);
    },
    [slides.length]
  );

  const startTimer = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => setCurrent((c) => (c + 1) % slides.length), 4000);
  }, [slides.length]);

  useEffect(() => {
    startTimer();
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [startTimer]);

  const handleNav = (dir: number) => {
    goTo(current + dir);
    startTimer();
  };

  return (
    <section className="px-4 md:px-8 lg:px-12 max-w-[1440px] mx-auto mt-6 md:mt-10">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-10 items-center">
        {/* Slideshow */}
        <div className="lg:col-span-7 relative">
          <div
            className="rounded-xl overflow-hidden shadow-xl relative group"
            style={{ aspectRatio: "16/10" }}
          >
            {slides.map((slide, i) => (
              <img
                key={slide.id}
                src={slide.image_url}
                alt={slide.alt_text}
                className="absolute inset-0 w-full h-full object-cover transition-opacity duration-1000"
                style={{ opacity: i === current ? 1 : 0 }}
                loading={i === 0 ? "eager" : "lazy"}
              />
            ))}

            {/* Arrows */}
            <button
              onClick={() => handleNav(-1)}
              className="absolute left-3 top-1/2 -translate-y-1/2 p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity z-10 shadow-md"
              style={{ backgroundColor: `${IVORY}CC`, color: PINE }}
            >
              <span className="material-symbols-outlined" style={{ fontSize: "20px" }}>chevron_left</span>
            </button>
            <button
              onClick={() => handleNav(1)}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity z-10 shadow-md"
              style={{ backgroundColor: `${IVORY}CC`, color: PINE }}
            >
              <span className="material-symbols-outlined" style={{ fontSize: "20px" }}>chevron_right</span>
            </button>

            {/* Dots */}
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-2 z-10">
              {slides.map((_, i) => (
                <button
                  key={i}
                  onClick={() => { goTo(i); startTimer(); }}
                  className="rounded-full transition-all duration-300"
                  style={{
                    width: i === current ? "20px" : "8px",
                    height: "8px",
                    backgroundColor: i === current ? IVORY : `${IVORY}80`,
                  }}
                />
              ))}
            </div>
          </div>

          {/* Floating quote card */}
          <div
            className="hidden md:block absolute -bottom-8 right-4 lg:-right-8 p-5 rounded-xl shadow-lg max-w-[240px] lg:max-w-xs z-20 border"
            style={{ backgroundColor: IVORY, borderColor: "rgba(20,56,31,0.15)" }}
          >
            <p
              className="leading-relaxed"
              style={{
                fontFamily: "'Playfair Display', serif",
                fontStyle: "italic",
                fontSize: "13px",
                color: "#605e57",
              }}
            >
              "Every piece tells a story of the hands that shaped it."
            </p>
          </div>
        </div>

        {/* Hero copy */}
        <div className="lg:col-span-5 lg:pl-8 pt-4 md:pt-10 lg:pt-0">
          <h2
            className="mb-4 md:mb-6 leading-tight"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(24px, 4vw, 40px)",
              fontWeight: 600,
              color: PINE,
            }}
          >
            Artisan crafts for a{" "}
            <em style={{ fontWeight: 400 }}>slower, intentional</em> life.
          </h2>
          <p
            className="mb-6 md:mb-8 leading-relaxed"
            style={{
              fontFamily: "'DM Sans', sans-serif",
              fontSize: "15px",
              color: "#605e57",
            }}
          >
            Discover our curated collection of hand-carved ceramics, sustainable
            textiles, and handcrafted stationery made by local artisans.
          </p>
          <div className="flex gap-3">
            <button
              className="px-5 py-2.5 rounded-lg font-semibold text-sm transition-opacity hover:opacity-90 active:scale-[0.98]"
              style={{ backgroundColor: PINE, color: IVORY, fontFamily: "'DM Sans', sans-serif" }}
            >
              Explore Collection
            </button>
            <button
              className="px-5 py-2.5 rounded-lg font-semibold text-sm transition-colors hover:bg-[rgba(20,56,31,0.06)] active:scale-[0.98]"
              style={{
                border: `1px solid rgba(20,56,31,0.3)`,
                color: PINE,
                fontFamily: "'DM Sans', sans-serif",
              }}
            >
              Our Story
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Trust Strip ──────────────────────────────────────────────────────────────

function TrustStrip() {
  return (
    <section
      className="mt-16 md:mt-20 px-4 md:px-8 lg:px-12 max-w-[1440px] mx-auto"
    >
      <div
        className="rounded-xl px-6 py-5 md:py-4 border"
        style={{ backgroundColor: "rgba(168,191,165,0.12)", borderColor: "rgba(20,56,31,0.12)" }}
      >
        <div className="grid grid-cols-2 md:grid-cols-4 gap-y-5 gap-x-4 md:gap-0 md:divide-x"
          style={{ "--tw-divide-color": "rgba(20,56,31,0.12)" } as React.CSSProperties}
        >
          {TRUST_ITEMS.map((item) => (
            <div
              key={item.title}
              className="flex flex-col sm:flex-row items-center sm:items-start gap-2 sm:gap-3 md:px-6 text-center sm:text-left"
            >
              <span
                className="text-xl shrink-0 mt-0.5"
                style={{ color: PINE, opacity: 0.7 }}
              >
                {item.icon}
              </span>
              <div>
                <p
                  className="font-semibold text-sm leading-tight"
                  style={{ fontFamily: "'DM Sans', sans-serif", color: PINE }}
                >
                  {item.title}
                </p>
                <p
                  className="text-xs mt-0.5 leading-snug"
                  style={{ fontFamily: "'DM Sans', sans-serif", color: "#7a7a6e" }}
                >
                  {item.desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── Occasion Quick Links ─────────────────────────────────────────────────────

function OccasionLinks() {
  return (
    <section className="mt-14 md:mt-16 px-4 md:px-8 lg:px-12 max-w-[1440px] mx-auto">
      <div className="mb-6 md:mb-8">
        <h3
          className="font-semibold"
          style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: "clamp(18px, 3vw, 26px)",
            color: PINE,
          }}
        >
          Shop by Occasion
        </h3>
        <p
          className="mt-1 text-sm"
          style={{ fontFamily: "'DM Sans', sans-serif", color: "#7a7a6e" }}
        >
          Find the perfect gift for every milestone
        </p>
      </div>

      {/* Mobile: 2-col grid; desktop: single row flex */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:flex lg:flex-row gap-3 md:gap-4">
        {OCCASIONS.map((occ) => (
          <a
            key={occ.slug}
            href="#"
            className="group relative overflow-hidden rounded-2xl flex-1 min-w-0 transition-transform duration-200 hover:-translate-y-1"
            style={{ textDecoration: "none" }}
          >
            <div
              className="relative overflow-hidden rounded-2xl"
              style={{ aspectRatio: "3/4" }}
            >
              <img
                src={occ.image}
                alt={occ.name}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                loading="lazy"
              />
              {/* Gradient overlay */}
              <div
                className="absolute inset-0"
                style={{
                  background:
                    "linear-gradient(to bottom, transparent 40%, rgba(13,38,20,0.75) 100%)",
                }}
              />
              {/* Label */}
              <div className="absolute bottom-0 left-0 right-0 p-3">
                <span
                  className="block text-center font-semibold text-sm leading-tight"
                  style={{ fontFamily: "'DM Sans', sans-serif", color: IVORY }}
                >
                  {occ.name}
                </span>
              </div>
            </div>
          </a>
        ))}
      </div>
    </section>
  );
}

// ─── Botanical Divider ────────────────────────────────────────────────────────

function BotanicalDivider() {
  return (
    <div
      className="relative w-full overflow-hidden mt-14 md:mt-16"
      style={{ height: "56px" }}
    >
      <img
        src={botanicalHero}
        alt=""
        aria-hidden
        className="absolute top-0 left-0 w-full object-cover"
        style={{ height: "120px", objectPosition: "center top", opacity: 0.18, filter: "saturate(0.8)" }}
        loading="lazy"
      />
      <div
        className="absolute inset-0"
        style={{ background: `linear-gradient(to bottom, ${IVORY} 0%, transparent 30%, transparent 70%, ${IVORY} 100%)` }}
      />
    </div>
  );
}

// ─── Product Card ─────────────────────────────────────────────────────────────

interface Product {
  id: number;
  name: string;
  seller_name: string;
  price_paise: number;
  image_url: string;
  avg_rating: number;
  review_count: number;
  is_bestseller?: boolean;
  listing_type: string;
}

function ProductCard({ product }: { product: Product }) {
  const price = `₹${(product.price_paise / 100).toLocaleString("en-IN")}`;
  const isCustom = product.listing_type === "custom";

  return (
    <div
      className="group rounded-xl border flex flex-col overflow-hidden cursor-pointer transition-shadow duration-300 hover:shadow-md"
      style={{
        backgroundColor: IVORY,
        borderColor: "rgba(20,56,31,0.15)",
      }}
    >
      {/* Image */}
      <div className="relative overflow-hidden" style={{ aspectRatio: "1/1" }}>
        {/* Badges */}
        <div className="absolute top-2 left-2 z-10 flex flex-col gap-1">
          {product.is_bestseller && (
            <span
              className="text-[10px] font-bold uppercase tracking-wide px-2 py-0.5 rounded-full text-white"
              style={{ backgroundColor: TERRACOTTA }}
            >
              Best Seller
            </span>
          )}
          {isCustom && (
            <span className="text-[10px] font-bold uppercase tracking-wide px-2 py-0.5 rounded-full text-white" style={{ backgroundColor: "#B492B7" }}>
              Custom
            </span>
          )}
        </div>

        <img
          src={product.image_url}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
          loading="lazy"
        />

        {/* Wishlist */}
        <button
          className="absolute top-2 right-2 p-1.5 rounded-full transition-all duration-200 hover:scale-110 active:scale-95"
          style={{ background: "rgba(250,246,238,0.85)" }}
          onClick={(e) => e.preventDefault()}
        >
          <span className="material-symbols-outlined" style={{ fontSize: "18px", color: PINE }}>
            favorite
          </span>
        </button>
      </div>

      {/* Info */}
      <div className="p-3 md:p-4 flex flex-col flex-1 gap-1">
        <div className="flex items-center justify-between gap-2">
          <span
            className="font-bold"
            style={{ fontFamily: "'DM Sans', sans-serif", fontSize: "15px", color: PINE }}
          >
            {price}
          </span>
          {product.review_count > 0 ? (
            <span className="text-xs flex items-center gap-0.5" style={{ color: "#605e57" }}>
              <span style={{ color: PINE }}>★</span>
              <span className="font-semibold" style={{ color: "#1C1C1A" }}>{product.avg_rating.toFixed(1)}</span>
              <span>({product.review_count})</span>
            </span>
          ) : (
            <span
              className="text-[10px] font-mono font-bold px-2 py-0.5 rounded tracking-wider uppercase"
              style={{ backgroundColor: "rgba(20,56,31,0.08)", color: PINE }}
            >
              New
            </span>
          )}
        </div>

        <h4
          className="font-bold leading-snug line-clamp-1"
          style={{ fontFamily: "'Playfair Display', serif", fontSize: "14px", color: "#1C1C1A" }}
        >
          {product.name}
        </h4>
        <span
          className="text-xs"
          style={{ fontFamily: "'DM Sans', sans-serif", color: "#7a7a6e" }}
        >
          By {product.seller_name}
        </span>

        <div className="mt-2">
          <button
            className="w-full py-2 rounded-lg font-semibold text-sm text-white transition-opacity hover:opacity-90 active:scale-[0.98]"
            style={{ backgroundColor: PINE }}
          >
            {isCustom ? "Talk to Seller" : "Add to Cart"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Sponsored Section ────────────────────────────────────────────────────────

function SponsoredSection() {
  const [idx, setIdx] = useState(0);
  const products = SPONSORED_PRODUCTS;

  const getPerView = () => {
    if (typeof window !== "undefined") {
      if (window.innerWidth >= 1024) return 3;
      if (window.innerWidth >= 640) return 2;
    }
    return 1;
  };

  const [perView, setPerView] = useState(3);

  useEffect(() => {
    setPerView(getPerView());
    const handler = () => setPerView(getPerView());
    window.addEventListener("resize", handler);
    return () => window.removeEventListener("resize", handler);
  }, []);

  const maxIdx = Math.max(0, products.length - perView);

  useEffect(() => {
    const timer = setInterval(() => setIdx((i) => (i >= maxIdx ? 0 : i + 1)), 3000);
    return () => clearInterval(timer);
  }, [maxIdx]);

  return (
    <section className="mt-10 px-4 md:px-8 lg:px-12 max-w-[1440px] mx-auto">
      <div
        className="rounded-xl border p-5 md:p-7"
        style={{ backgroundColor: IVORY, borderColor: "rgba(20,56,31,0.15)" }}
      >
        <div className="flex justify-between items-end mb-5">
          <div>
            <h3
              className="font-semibold flex items-center gap-2"
              style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(16px,2.5vw,22px)", color: PINE }}
            >
              <span className="material-symbols-outlined" style={{ fontSize: "20px", fontVariationSettings: "'FILL' 1" }}>star</span>
              Sponsored
            </h3>
            <p className="text-sm mt-0.5" style={{ fontFamily: "'DM Sans', sans-serif", color: "#7a7a6e" }}>
              Featured treasures from our creative community
            </p>
          </div>
        </div>

        <div className="overflow-hidden">
          <div
            className="flex gap-4 transition-transform duration-300 ease-in-out"
            style={{ transform: `translateX(calc(-${idx} * ((100% + 1rem) / ${perView})))` }}
          >
            {products.map((p) => (
              <div key={p.id} className="flex-shrink-0" style={{ width: `calc((100% - ${(perView - 1) * 16}px) / ${perView})` }}>
                <ProductCard product={p} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── For You Section ──────────────────────────────────────────────────────────

function ForYouSection() {
  return (
    <section id="for-you-section" className="mt-12 md:mt-16 px-4 md:px-8 lg:px-12 max-w-[1440px] mx-auto">
      <div className="flex justify-between items-end mb-5 md:mb-6">
        <div>
          <h3
            style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(18px,3vw,26px)", color: PINE, fontWeight: 600 }}
          >
            For You
          </h3>
          <p className="text-sm mt-0.5" style={{ fontFamily: "'DM Sans', sans-serif", color: "#7a7a6e" }}>
            Handpicked treasures just for you
          </p>
        </div>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4 lg:gap-5">
        {MOCK_PRODUCTS.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </section>
  );
}

// ─── Category Row ─────────────────────────────────────────────────────────────

function CategoryRow({ category }: { category: { display_name: string; slug: string } }) {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (dir: number) => {
    if (!scrollRef.current) return;
    scrollRef.current.scrollBy({ left: dir * 300, behavior: "smooth" });
  };

  return (
    <div className="mb-12">
      <div className="flex justify-between items-baseline mb-4 md:mb-5">
        <h3
          className="font-semibold"
          style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(16px,2.5vw,22px)", color: PINE }}
        >
          {category.display_name}
        </h3>
        <a
          href="#"
          className="text-sm font-semibold flex items-center gap-1 hover:underline"
          style={{ color: PINE, fontFamily: "'DM Sans', sans-serif" }}
        >
          View All
          <span className="material-symbols-outlined" style={{ fontSize: "16px" }}>chevron_right</span>
        </a>
      </div>

      <div className="relative group">
        <button
          onClick={() => scroll(-1)}
          className="absolute left-[-14px] top-1/2 -translate-y-1/2 p-2 rounded-full border shadow-md z-10 opacity-0 group-hover:opacity-100 transition-all duration-200 active:scale-95 hidden lg:flex"
          style={{ backgroundColor: IVORY, color: PINE, borderColor: "rgba(20,56,31,0.2)" }}
        >
          <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>chevron_left</span>
        </button>

        <div
          ref={scrollRef}
          className="flex gap-4 overflow-x-auto pb-3 snap-x snap-mandatory"
          style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
        >
          {MOCK_PRODUCTS.concat(MOCK_PRODUCTS.slice(0, 4)).map((p, i) => (
            <div key={`${p.id}-${i}`} className="flex-shrink-0 snap-start" style={{ width: "clamp(200px, 22vw, 270px)" }}>
              <ProductCard product={{ ...p, id: p.id + i * 100 }} />
            </div>
          ))}
        </div>

        <button
          onClick={() => scroll(1)}
          className="absolute right-[-14px] top-1/2 -translate-y-1/2 p-2 rounded-full border shadow-md z-10 opacity-0 group-hover:opacity-100 transition-all duration-200 active:scale-95 hidden lg:flex"
          style={{ backgroundColor: IVORY, color: PINE, borderColor: "rgba(20,56,31,0.2)" }}
        >
          <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>chevron_right</span>
        </button>
      </div>
    </div>
  );
}

function CategoryRowsSection() {
  return (
    <section className="mt-14 md:mt-16 px-4 md:px-8 lg:px-12 max-w-[1440px] mx-auto">
      {MOCK_CATEGORIES.map((cat) => (
        <CategoryRow key={cat.slug} category={cat} />
      ))}
    </section>
  );
}

// ─── Footer ───────────────────────────────────────────────────────────────────

function Footer() {
  const footerLinks = {
    Company: ["About Us", "Our Story"],
    "For Sellers": ["Sell on Tohfa", "Seller Dashboard"],
    "For Buyers": ["AI Gift Guide"],
    Support: ["Contact Us", "Refunds & Disputes", "Terms and Conditions", "FAQs"],
  };

  return (
    <footer className="relative overflow-hidden mt-16" style={{ backgroundColor: PINE, color: IVORY }}>
      {/* Ghost watermark */}
      <div
        className="absolute bottom-[-10%] right-[-5%] opacity-[0.04] pointer-events-none select-none"
      >
        <span className="material-symbols-outlined" style={{ fontSize: "500px", color: "white" }}>
          local_florist
        </span>
      </div>

      {/* Botanical accent top */}
      <div className="relative w-full overflow-hidden" style={{ height: "60px" }}>
        <img
          src={botanicalHero}
          alt=""
          aria-hidden
          className="absolute top-0 left-0 w-full object-cover"
          style={{ height: "120px", objectPosition: "center top", opacity: 0.12, filter: "saturate(0.6)" }}
          loading="lazy"
        />
        <div
          className="absolute inset-0"
          style={{ background: `linear-gradient(to bottom, ${PINE} 0%, transparent 50%, ${PINE} 100%)` }}
        />
      </div>

      {/* Main grid */}
      <div className="max-w-[1280px] mx-auto px-6 pt-10 pb-8 relative z-10">
        <div
          className="tohfa-footer-inner grid gap-10 mb-16"
          style={{
            gridTemplateColumns: "repeat(1, 1fr)",
          }}
        >
          {/* Brand col */}
          <div>
            <h2
              style={{
                fontFamily: "'Playfair Display', serif",
                fontSize: "44px",
                fontStyle: "italic",
                color: IVORY,
                marginBottom: "12px",
              }}
            >
              Tohfa.
            </h2>
            <p
              style={{ fontFamily: "'DM Sans', sans-serif", color: IVORY, marginBottom: "6px", fontWeight: 500 }}
            >
              Thoughtful Gifting, Made Effortless.
            </p>
            <p
              style={{ fontFamily: "'DM Sans', sans-serif", color: "#A8B89A", lineHeight: 1.6, fontSize: "14px" }}
            >
              India&apos;s first home for handcrafted gifts, celebrating the soul of artisanal craftsmanship.
            </p>
          </div>

          {/* Link cols */}
          {Object.entries(footerLinks).map(([heading, links]) => (
            <div key={heading}>
              <h3
                className="mb-6"
                style={{
                  fontFamily: "'Space Mono', monospace",
                  fontSize: "11px",
                  letterSpacing: "0.15em",
                  textTransform: "uppercase",
                  color: "rgba(168,191,165,0.7)",
                }}
              >
                {heading}
              </h3>
              <ul className="flex flex-col gap-3">
                {links.map((link) => (
                  <li key={link}>
                    <a
                      href="#"
                      className="text-sm transition-colors hover:text-[#A8BFA5]"
                      style={{ fontFamily: "'DM Sans', sans-serif", color: IVORY, textDecoration: "none" }}
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Divider */}
        <div className="w-full h-px mb-8" style={{ backgroundColor: "rgba(255,255,255,0.1)" }} />

        {/* Bottom bar */}
        <div className="flex flex-col md:flex-row items-center justify-center gap-4">
          <p
            className="text-sm flex items-center gap-1.5"
            style={{ fontFamily: "'DM Sans', sans-serif", color: "rgba(250,246,238,0.7)" }}
          >
            Made with{" "}
            <span className="material-symbols-outlined" style={{ fontSize: "16px", color: "#C85A32", fontVariationSettings: "'FILL' 1" }}>
              favorite
            </span>{" "}
            in India
          </p>
        </div>
      </div>

      {/* Botanical bottom accent */}
      <div className="relative w-full overflow-hidden" style={{ height: "50px" }}>
        <img
          src={botanicalHero}
          alt=""
          aria-hidden
          className="absolute w-full object-cover"
          style={{ bottom: 0, height: "100px", objectPosition: "center top", opacity: 0.08 }}
          loading="lazy"
        />
        <div
          className="absolute inset-0"
          style={{ background: `linear-gradient(to bottom, ${PINE} 0%, transparent 100%)` }}
        />
      </div>

      {/* Responsive footer grid */}
      <style>{`
        @media (min-width: 768px) {
          .tohfa-footer-inner { grid-template-columns: 2fr 1fr 1fr 1fr 1fr !important; }
        }
      `}</style>
    </footer>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────

export default function App() {
  return (
    <>
      {/* Material Symbols for icons */}
      <link
        rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&display=block"
      />
      <style>{`
        body { background-color: #FAF6EE; }
        .material-symbols-outlined { font-variation-settings: 'FILL' 0, 'wght' 300, 'GRAD' 0, 'opsz' 24; }
        ::-webkit-scrollbar { display: none; }
        * { scrollbar-width: none; }
      `}</style>

      <div style={{ backgroundColor: "#FAF6EE", minHeight: "100vh", fontFamily: "'DM Sans', sans-serif" }}>
        <Navbar />

        <main>
          {/* 1. Botanical Intro Banner */}
          <BotanicalBanner />

          {/* 2. Hero Slideshow */}
          <HeroSlideshow />

          {/* 3. Trust Strip */}
          <TrustStrip />

          {/* 4. Occasion Quick Links */}
          <OccasionLinks />

          {/* Botanical Divider */}
          <BotanicalDivider />

          {/* 5. Sponsored Section */}
          <SponsoredSection />

          {/* 6. For You */}
          <ForYouSection />

          {/* Botanical Divider */}
          <BotanicalDivider />

          {/* 7. Category Rows */}
          <CategoryRowsSection />
        </main>

        <Footer />
      </div>
    </>
  );
}
