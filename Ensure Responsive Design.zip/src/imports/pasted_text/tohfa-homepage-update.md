Update the existing Tohfa homepage design with the following changes ONLY.

IMPORTANT:
Do NOT redesign, restructure, replace, or remove any existing homepage content or sections unless explicitly instructed below.

Preserve the existing:
- navigation/taskbar
- slideshow/carousel
- categories
- ZipGift section
- product listings
- existing content
- footer structure
- DM Sans body typography
- existing functionality
- existing terracotta accent

This is an enhancement of the current homepage, NOT a complete redesign.

==================================================
1. BACKGROUND COLOR SHIFT
==================================================

Replace the current warm cream background:

#FFF8E7

with a much softer ivory-white:

Primary target:
#FAF6EE

Alternative close shade:
#F9F4E8

The new background should feel:

- white-leaning
- soft
- sophisticated
- slightly warm
- NOT yellow
- NOT beige-heavy
- NOT cream-heavy

It should complement:

Deep Green:
#0D2614

Pine Green:
#14381F

Forest Green:
#285C3A

Muted Moss:
#587A5B

Sage:
#A8BFA5

Keep the existing terracotta accent:

#C85A32

UNCHANGED.

Apply the new ivory background consistently across the homepage wherever the current warm cream background is being used.

Do NOT recolor existing green or terracotta elements unnecessarily.

==================================================
2. NEW STATIC TOHFA INTRO BANNER
==================================================

ADD a new full-width static intro banner ABOVE the existing hero/slideshow.

Do NOT remove or replace the existing slideshow.

The new hierarchy must be:

TOHFA INTRO BANNER
↓
EXISTING IMAGE SLIDESHOW / CAROUSEL
↓
TRUST STRIP
↓
OCCASION QUICK LINKS
↓
EXISTING CATEGORIES
↓
EXISTING ZIPGIFT SECTION
↓
EXISTING PRODUCT LISTINGS
↓
FOOTER

--------------------------------------------------
VISUAL DIRECTION
--------------------------------------------------

Create a premium dark-green botanical image featuring hanging floral/foliage arrangements.

Visual references:

- green hydrangeas
- hanging amaranthus
- roses
- layered greenery
- lush botanical textures
- elegant floral arrangement

Background should be predominantly dark green.

The image should feel:

- premium
- editorial
- botanical
- sophisticated
- tactile
- warm
- Indian gifting/luxury adjacent

Do NOT make it colorful or overly floral.

The dominant visual tone should remain dark green.

--------------------------------------------------
IMAGE BEHAVIOR
--------------------------------------------------

Use ONE static optimized image.

NO:
- video
- autoplay animation
- entrance animation
- parallax
- heavy motion
- animated background

Optimize the image so it loads efficiently on both desktop and mobile.

--------------------------------------------------
GRADIENT BLEND
--------------------------------------------------

The bottom of the botanical image should gradually fade from:

dark green

↓

deep green

↓

transparent / soft ivory

↓

#FAF6EE

The gradient must seamlessly merge the banner into the homepage background.

There should NOT be a harsh rectangular boundary between the image and ivory page.

--------------------------------------------------
TOHFA TYPOGRAPHY
--------------------------------------------------

Place:

"Tohfa"

in the vertical center of the banner.

Use a large elegant serif display font.

The word should feel:

- editorial
- luxurious
- calm
- confident
- sophisticated

Text color:

approximately #FAF6EE

It should match the new ivory background tone.

Do NOT use stark pure white (#FFFFFF).

Do NOT add a subtitle unless one already exists in the design.

Keep the typography minimal.

==================================================
3. EXISTING SLIDESHOW
==================================================

Immediately below the new botanical intro banner:

KEEP THE EXISTING IMAGE SLIDESHOW/CAROUSEL EXACTLY AS IT CURRENTLY EXISTS.

Do not redesign it.

Do not change:
- images
- content
- controls
- layout
- typography
- functionality

Only adjust surrounding spacing if required to create a clean visual transition from:

INTRO BANNER
→
SLIDESHOW

==================================================
4. TRUST / SOCIAL-PROOF STRIP
==================================================

ADD a thin horizontal trust strip immediately BELOW the slideshow.

Purpose:

Build confidence immediately after the visual hook.

This should be subtle and premium — NOT a row of large cards.

Use four compact items:

✨  Made With Meaning
    Reinforces Tohfa's emotional positioning

🎨  Customised For You
    Highlights Tohfa's customisation value

🤝  Trusted Creators
    Builds marketplace confidence

📦  Pan-India Delivery
    Removes delivery uncertainty

--------------------------------------------------
DESIGN
--------------------------------------------------

Use:

- thin horizontal layout
- generous horizontal spacing
- small refined icons
- short text
- minimal typography
- ivory/sage background
- dark green text

Do NOT make them chunky cards.

Do NOT add large shadows.

Do NOT use excessive borders.

The strip should feel almost like a premium editorial information ribbon.

On mobile:

Stack into a clean 2 × 2 arrangement or horizontally scroll only if absolutely necessary.

Prefer 2 × 2 for usability.

==================================================
5. OCCASION-BASED QUICK LINKS
==================================================

ADD a new occasion discovery section BELOW the trust strip and ABOVE the existing categories.

Purpose:

Allow users to immediately navigate based on WHY they are gifting.

This should be faster and more intuitive than asking users to browse generic product categories.

--------------------------------------------------
OCCASION TILES
--------------------------------------------------

Create rounded-rectangle image tiles for occasions such as:

- Anniversary
- Birthday
- Rakhi
- Wedding
- Friendship
- Mother's Day
- Father's Day

Use only occasions that are relevant/available in the existing Tohfa product/category system.

Do NOT invent unsupported categories.

--------------------------------------------------
TILE DESIGN
--------------------------------------------------

Each tile should be:

- image-led
- rounded rectangle
- visually premium
- relatively compact
- easy to scan

Each tile contains:

IMAGE
+
OCCASION NAME

The image should communicate the occasion emotionally.

Examples:

Anniversary → romantic gifting
Birthday → celebration/gift moment
Rakhi → sibling/family gifting
Wedding → elegant wedding gift
Friendship → warm personal gifting

Avoid generic stock imagery wherever possible.

--------------------------------------------------
LAYOUT
--------------------------------------------------

Desktop:

A clean horizontal row/grid of occasion tiles.

Mobile:

Responsive horizontal scroll OR 2-column grid depending on available width.

Do not make the section excessively tall.

The user should be able to scan all occasions quickly.

--------------------------------------------------
UX
--------------------------------------------------

Each tile should be clickable if the existing application supports category/occasion navigation.

Do NOT create a new backend feature or filtering system.

Use existing navigation/data wherever possible.

==================================================
6. BOTANICAL SECTION DIVIDER
==================================================

Introduce a subtle recurring botanical motif throughout the page.

Create a very thin horizontal botanical divider using the SAME visual language as the hanging-greenery hero.

Height:

approximately 40–60px.

Purpose:

Separate major homepage blocks without using generic horizontal rules.

--------------------------------------------------
IMPORTANT
--------------------------------------------------

The divider must remain SUBTLE.

It should NOT look like another hero banner.

Use:

- cropped greenery
- hanging foliage
- dark/medium green
- subtle fade
- lots of visual breathing room

Do NOT repeat the full floral composition.

Do NOT use this divider after every section.

Use it only between major blocks where it improves visual rhythm.

Suggested placement:

INTRO / SLIDESHOW AREA
↓
TRUST + OCCASION DISCOVERY
↓
EXISTING CATEGORIES

and/or

MAJOR CONTENT BLOCK
↓
PRODUCT DISCOVERY

Use restraint.

==================================================
7. PRODUCT CARD MICRO-INTERACTIONS
==================================================

Add subtle hover interactions to existing product cards.

IMPORTANT:

These interactions should happen ONLY on interaction.

NO entrance animations.

NO page-load animations.

NO automatic motion.

--------------------------------------------------
HOVER BEHAVIOR
--------------------------------------------------

On desktop hover:

- very subtle image zoom
- gentle transition
- optional slight elevation
- subtle CTA/link emphasis
- button underline if applicable

Animation should be:

fast
subtle
premium
controlled

Avoid:

- bouncing
- scaling the entire card aggressively
- flashy effects
- gradients
- glowing effects
- excessive movement

The product image should feel slightly more alive when hovered.

On mobile, do not force hover behavior.

==================================================
8. FOOTER BOTANICAL ACCENT
==================================================

Keep the existing footer structure EXACTLY AS IT IS.

Do NOT redesign the footer.

Add ONLY a subtle botanical accent at the bottom/edge of the footer.

The accent should visually mirror the botanical intro banner.

--------------------------------------------------
VISUAL
--------------------------------------------------

Use a small cropped version of the hanging greenery motif.

It should:

- emerge subtly from the bottom of the footer
- fade naturally
- use the same green botanical visual language
- feel like a visual "bookend" to the homepage

The effect should communicate:

TOP OF PAGE
↓
botanical greenery
↓
TOHFA
↓
homepage
↓
botanical greenery
↓
BOTTOM OF PAGE

Do NOT make the footer greenery large.

Do NOT let it compete with footer content.

Do NOT change footer typography, links, layout, or functionality.

==================================================
9. OVERALL HOMEPAGE FLOW
==================================================

The final homepage hierarchy should be:

1. EXISTING LOCKED NAVBAR / TASKBAR

2. NEW TOHFA BOTANICAL INTRO
   Dark-green hanging greenery
   +
   "Tohfa" serif typography
   +
   ivory gradient

3. EXISTING IMAGE SLIDESHOW

4. NEW TRUST / SOCIAL-PROOF STRIP
   Made With Meaning
   Customised For You
   Trusted Creators
   Pan-India Delivery

5. NEW OCCASION QUICK LINKS
   Anniversary
   Birthday
   Rakhi
   Wedding
   etc.

6. EXISTING CATEGORIES

7. EXISTING ZIPGIFT SECTION

8. EXISTING PRODUCT LISTINGS
   + subtle hover interactions

9. EXISTING FOOTER
   + subtle botanical accent

==================================================
10. RESPONSIVE DESIGN
==================================================

Everything must remain fully responsive.

Do NOT create separate desktop and mobile versions.

Use ONE responsive implementation.

--------------------------------------------------
DESKTOP
--------------------------------------------------

The botanical intro should feel wide and editorial.

The "Tohfa" wordmark should remain visually dominant but not oversized.

Trust strip:

4 items in one row.

Occasion tiles:

horizontal visual grid.

--------------------------------------------------
TABLET
--------------------------------------------------

Gradually reduce:

- spacing
- tile width
- typography scale

while maintaining the same hierarchy.

--------------------------------------------------
MOBILE
--------------------------------------------------

The botanical intro should scale proportionally.

IMPORTANT:

Do NOT crop the "Tohfa" text.

Do NOT allow the gradient to break.

Do NOT create awkward image cropping.

Trust strip:

2 × 2 compact grid.

Occasion tiles:

2-column responsive grid OR clean horizontal scrolling.

Product cards:

retain existing responsive behavior.

Botanical dividers:

remain subtle and never consume excessive vertical space.

Footer botanical accent:

remain compact.

==================================================
11. PERFORMANCE
==================================================

The new visual additions must remain lightweight.

Use:

- optimized static image
- CSS gradients
- CSS hover transitions
- compressed assets
- lazy loading where appropriate

Do NOT introduce:

- video
- autoplay
- heavy animation libraries
- large background animations
- unnecessary JavaScript

The page should remain fast.

==================================================
12. DO NOT CHANGE THESE
==================================================

Unless explicitly instructed:

DO NOT change:

- navbar/taskbar
- slideshow content
- categories content
- ZipGift section
- product listing functionality
- footer structure
- existing routes
- backend
- database
- APIs
- authentication
- payment functionality
- existing product data
- existing content

==================================================
13. DESIGN LANGUAGE
==================================================

The final page should feel:

PREMIUM
+
EDITORIAL
+
BOTANICAL
+
WARM
+
MODERN
+
EMOTIONAL
+
INDIAN

The botanical imagery should not make Tohfa look like a flower shop.

This is extremely important.

The greenery is a BRANDING MOTIF, not the product category.

The website should still clearly communicate:

TOHFA = meaningful + customised + unique gifting.

==================================================
14. FINAL DESIGN CHECK
==================================================

Before finalizing, verify:

[ ] Background is soft ivory-white, not yellow cream

[ ] #CDEDB3 / old Green Tea is NOT used

[ ] Terracotta #C85A32 remains unchanged

[ ] Botanical intro is static

[ ] No video

[ ] No entrance animations

[ ] "Tohfa" is elegant serif

[ ] Hero fades naturally into ivory

[ ] Existing slideshow remains intact

[ ] Trust strip appears immediately below slideshow

[ ] Trust strip uses:
    Made With Meaning
    Customised For You
    Trusted Creators
    Pan-India Delivery

[ ] Occasion links appear before existing categories

[ ] Occasion tiles are image-led and easy to scan

[ ] Botanical divider is subtle and only used between major blocks

[ ] Product cards have subtle hover interaction

[ ] No load animations

[ ] Footer structure remains unchanged

[ ] Footer receives only a subtle botanical accent

[ ] Desktop is responsive

[ ] Mobile is responsive

[ ] No duplicate desktop/mobile frontend

[ ] No new backend functionality

[ ] No unnecessary new features

[ ] Existing sections have NOT been redesigned

[ ] Overall page feels cohesive rather than feature-heavy

FINAL PRINCIPLE:

DO NOT TURN THIS INTO A DIFFERENT HOMEPAGE.

The existing Tohfa homepage remains the foundation.

These additions should feel like they were always part of the same design system.

The goal is:

SUBTLE UPGRADE
NOT
COMPLETE REDESIGN.